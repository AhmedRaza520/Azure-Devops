﻿namespace AzUnzipEverything
{
    public static class Constants
    {
        public static class SupportedExtensions
        {
            public const string Zip = ".zip";
            public const string Rar = ".rar";
        }
    }
}